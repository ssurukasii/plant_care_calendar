<?php
session_start();
if (!isset($_SESSION['plants'])) $_SESSION['plants'] = [];
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function require_login() { if (empty($_SESSION['demo_user'])) { header('Location: index.php'); exit; } }
function redirect($page) { header('Location: '.$page); exit; }
function valid_email($email) { return filter_var($email, FILTER_VALIDATE_EMAIL) !== false; }
function due($plant, $date, $field) {
  $diff = (new DateTime($plant['created']))->diff(new DateTime($date));
  return !$diff->invert && $diff->days % (int)$plant[$field] === 0;
}
?>