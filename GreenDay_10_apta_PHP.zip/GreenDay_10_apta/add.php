<?php require 'includes/functions.php';require_login();$errors=[];
if($_SERVER['REQUEST_METHOD']==='POST') {
 $name=trim($_POST['name']??'');$type=trim($_POST['type']??'');$place=trim($_POST['place']??'');$water=filter_var($_POST['water']??null,FILTER_VALIDATE_INT);$fert=filter_var($_POST['fert']??null,FILTER_VALIDATE_INT);$light=$_POST['light']??'';
 if($name===''||mb_strlen($name)>100)$errors[]='Өсімдік атауын 1–100 таңбамен енгізіңіз.';
 if($type===''||mb_strlen($type)>100)$errors[]='Өсімдік түрін енгізіңіз.';
 if(!$water||$water<1||$water>365||!$fert||$fert<1||$fert>365)$errors[]='Күтім жиілігі 1–365 күн аралығында болсын.';
 if(!in_array($light,['Аз','Орташа','Көп'],true))$errors[]='Жарық деңгейін таңдаңыз.';
 if(!$errors){$_SESSION['plants'][]=['id'=>uniqid('plant_',true),'name'=>$name,'type'=>$type,'place'=>$place,'water'=>$water,'fert'=>$fert,'light'=>$light,'created'=>date('Y-m-d')];redirect('plants.php');}
}
include 'includes/header.php'; ?>
<h2>🌱 Өсімдік қосу</h2><div class="hero"><div class="plant">🌿</div><p>Өсімдіктің күтім параметрлерін толтырыңыз</p></div>
<?php foreach($errors as $e): ?><p class="alert"><?=h($e)?></p><?php endforeach; ?>
<form method="post" action="add.php"><input name="name" required maxlength="100" value="<?=h($_POST['name']??'')?>" placeholder="Өсімдіктің атауы"><input name="type" required maxlength="100" value="<?=h($_POST['type']??'')?>" placeholder="Түрі (раушан)"><input name="place" value="<?=h($_POST['place']??'')?>" placeholder="Орналасқан жері"><h3>Күтім шарттары</h3><label>Суару жиілігі (күн)</label><input type="number" name="water" min="1" max="365" value="<?=h($_POST['water']??7)?>" required><label>Тыңайтқыш беру (күн)</label><input type="number" name="fert" min="1" max="365" value="<?=h($_POST['fert']??30)?>" required><label>Жарық қажеттілігі</label><select name="light"><option>Орташа</option><option>Аз</option><option>Көп</option></select><button class="primary">Сақтау</button></form><a href="plants.php">← Артқа</a>
<?php include 'includes/footer.php'; ?>