<?php require 'includes/functions.php'; if(!empty($_SESSION['demo_user'])) redirect('plants.php'); $error='';
if($_SERVER['REQUEST_METHOD']==='POST') { $email=trim($_POST['email']??''); $password=$_POST['password']??''; $name=trim($_POST['name']??''); $mode=$_POST['mode']??'login';
 if(!valid_email($email)||strlen($password)<6||($mode==='register'&&$name==='')) $error='Email, аты-жөні және құпиясөзді дұрыс енгізіңіз (кемінде 6 таңба).';
 else { $_SESSION['demo_user']=$mode==='register'?$name:$email; redirect('plants.php'); }
}
include 'includes/header.php'; ?>
<div class="hero"><div class="plant">🪴</div><h2>Қош келдіңіз!</h2><p>Өсімдіктеріңізге бірге күтім жасайық</p></div>
<?php if($error): ?><p class="alert"><?=h($error)?></p><?php endif; ?>
<div class="card"><h2>Жүйеге кіру / тіркелу</h2><form method="post" action="index.php"><label>Аты-жөні (тіркелу үшін)</label><input name="name" placeholder="Аты-жөніңіз"><label>Email</label><input name="email" type="email" required placeholder="Электрондық пошта"><label>Құпиясөз</label><input name="password" type="password" minlength="6" required placeholder="Кемінде 6 таңба"><button class="primary" name="mode" value="login">Кіру</button><button class="secondary" style="width:100%" name="mode" value="register">Тіркелу</button></form><p class="hint">10-апта: демонстрациялық кіру. Нақты аккаунттарды сақтау 11-аптада MySQL арқылы жасалады.</p></div>
<?php include 'includes/footer.php'; ?>