<?php require 'includes/functions.php'; require_login(); $q=trim($_GET['q']??''); include 'includes/header.php'; ?>
<div class="row"><h2>Менің өсімдіктерім 🪴</h2><a class="secondary" href="add.php">+ Қосу</a></div>
<form method="get"><input name="q" value="<?=h($q)?>" placeholder="Өсімдікті іздеу"><button class="secondary">Іздеу</button></form>
<?php $count=0; foreach($_SESSION['plants'] as $p): if($q!==''&&mb_stripos($p['name'].' '.$p['type'],$q)===false)continue; $count++; ?>
<div class="card"><h3>🌿 <?=h($p['name'])?></h3><p><?=h($p['type'])?> · <?=h($p['place'])?></p><p class="small">💧 Әр <?=h($p['water'])?> күн · 🌱 Әр <?=h($p['fert'])?> күн · ☀️ <?=h($p['light'])?></p></div>
<?php endforeach; if(!$count): ?><div class="card">Өсімдік табылмады. «+ Қосу» батырмасын басыңыз.</div><?php endif; ?>
<?php include 'includes/footer.php'; ?>