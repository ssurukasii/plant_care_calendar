import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.stream.*;

public class UniversityApp {
    // түс
    static final Color C_BG         = new Color(244, 246, 249);
    static final Color C_CARD       = Color.WHITE;
    static final Color C_INPUT      = Color.WHITE;
    static final Color C_SIDE       = new Color(255, 255, 255);
    static final Color C_BORDER     = new Color(220, 224, 230);
    static final Color C_RED        = new Color(194, 24, 71);
    static final Color C_TEXT       = new Color(40, 44, 55);
    static final Color C_MUTED      = new Color(120, 130, 145);
    static final Color C_BLUE       = new Color(30, 144, 255);
    static final Color C_GREEN      = new Color(40, 167,     69);
    static final Color C_SIDE_DARK  = new Color(43, 47, 54);
    static final Color C_SIDE_HOVER = new Color(55, 60, 69);
    static final Color C_SIDE_TEXT  = new Color(210, 215, 225);
    static final Color C_REPORTS_BG = new Color(130, 10, 30);

    static final Font F_TITLE  = new Font("Segoe UI", Font.BOLD, 22);
    static final Font F_HEAD   = new Font("Segoe UI", Font.BOLD, 14);
    static final Font F_BODY   = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font F_BOLD   = new Font("Segoe UI", Font.BOLD, 13);
    static final Font F_SMALL  = new Font("Segoe UI", Font.PLAIN, 11);
    //деректер базасы
    Database db = Database.get();
    Database.User currentUser;
    JFrame mainFrame;
    JPanel contentArea;
    //текст шығару
    JLabel lbl(String t, Font f, Color c) {
        JLabel l = new JLabel(t); l.setFont(f); l.setForeground(c); return l;
    }
    //текст
    private JTextField createField(JTextField tf) {
        tf.setBackground(C_INPUT); tf.setForeground(C_TEXT); tf.setFont(F_BODY); tf.setCaretColor(C_RED);
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));
        return tf;
    }

    JTextField tf() { return createField(new JTextField()); }
    JPasswordField pf() { return (JPasswordField) createField(new JPasswordField()); }
    //буттон
    JButton btn(String t, Color bg, Color fg) {
        JButton b = new JButton(t); b.setBackground(bg); b.setForeground(fg); b.setFont(F_BOLD);
        b.setBorderPainted(false); b.setFocusPainted(false); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if (bg == C_INPUT) {
            b.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(9, 19, 9, 19)));
        } else {
            b.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        }
        return b;
    }

    JButton btnP(String t){ return btn(t, C_RED, Color.WHITE); }
    JButton btnS(String t){ return btn(t, new Color(40, 167, 69), Color.WHITE); }
    JButton btnD(){ return btn("Жою", new Color(220, 53, 69), Color.WHITE); }
    JButton btnN(){ return btn("Бас тарту", C_INPUT, C_TEXT); }
    //кесте
    void styleTable(JTable t) {
        t.setBackground(C_CARD); t.setForeground(C_TEXT); t.setFont(F_BODY); t.setRowHeight(38); t.setShowGrid(true);
        t.setGridColor(C_BORDER); t.setSelectionBackground(new Color(194, 24, 71, 20)); t.setSelectionForeground(C_TEXT);
        t.getTableHeader().setBackground(C_BG); t.getTableHeader().setForeground(C_TEXT); t.getTableHeader().setFont(F_BOLD);
        t.getTableHeader().setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, C_BORDER)); t.setFillsViewportHeight(true);
    }
    //прокрутка
    JScrollPane scroll(JComponent c) {
        JScrollPane sp = new JScrollPane(c); sp.setBorder(BorderFactory.createLineBorder(C_BORDER, 1));
        sp.getViewport().setBackground(c.getBackground()); sp.setBackground(c.getBackground()); sp.getVerticalScrollBar().setUnitIncrement(16);
        return sp;
    }
    //тышқан
    private void makeDraggable(Component target, JFrame frame) {
        int[] ds = {0, 0};
        target.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { ds[0] = e.getX(); ds[1] = e.getY(); }
        });
        target.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) { frame.setLocation(frame.getX() + e.getX() - ds[0], frame.getY() + e.getY() - ds[1]); }
        });
    }
    //логин
    public void showLogin() {
        JFrame f = new JFrame(); f.setUndecorated(true); f.setSize(850, 520); f.setLocationRelativeTo(null); f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(C_BG);

        JPanel left = new JPanel(new GridBagLayout()) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, C_RED, getWidth(), getHeight(), new Color(130, 10, 45)));
                g2.fillRect(0, 0, getWidth(), getHeight()); g2.dispose();
            }
        };
        left.setPreferredSize(new Dimension(340, 520));
        JPanel brand = new JPanel(); brand.setOpaque(false); brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));

        JLabel logo = lbl("Platonus АЖ", new Font("Segoe UI", Font.BOLD, 30), Color.WHITE); logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = lbl("Университет Ақпараттық Жүйесі", F_SMALL, new Color(255, 255, 255, 180)); sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        brand.add(Box.createVerticalStrut(40)); brand.add(logo); brand.add(Box.createVerticalStrut(6)); brand.add(sub); brand.add(Box.createVerticalStrut(30));

        for (String[] cr : new String[][]{{"teacher / teacher123", "Оқытушы"}, {"student / student123", "Студент"}}) {
            JPanel hint = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4)); hint.setOpaque(false);
            hint.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 40), 1), BorderFactory.createEmptyBorder(3, 8, 3, 8)));
            hint.add(lbl(cr[0], new Font("Consolas", Font.PLAIN, 11), new Color(255, 255, 255, 200))); hint.setAlignmentX(Component.CENTER_ALIGNMENT);
            brand.add(hint); brand.add(Box.createVerticalStrut(6));
        }
        left.add(brand);

        JPanel right = new JPanel(new GridBagLayout()); right.setOpaque(false);
        JPanel card = new JPanel(); card.setBackground(C_CARD); card.setPreferredSize(new Dimension(360, 380));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS)); card.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(30, 30, 30, 30)));

        JLabel title = lbl("Жүйеге кіру", F_TITLE, C_TEXT), subtitle = lbl("Тіркелгі мәліметтерін енгізіңіз", F_BODY, C_MUTED), errLbl = lbl("", F_BODY, C_RED);
        title.setAlignmentX(Component.LEFT_ALIGNMENT); subtitle.setAlignmentX(Component.LEFT_ALIGNMENT); errLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField userField = tf(); userField.setMaximumSize(new Dimension(9999, 40)); userField.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPasswordField passField = pf(); passField.setMaximumSize(new Dimension(9999, 40)); passField.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton loginBtn = btnP("Кіру"); loginBtn.setMaximumSize(new Dimension(9999, 42)); loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(title); card.add(Box.createVerticalStrut(4)); card.add(subtitle); card.add(Box.createVerticalStrut(24));
        card.add(lbl("Пайдаланушы аты", F_BOLD, C_TEXT)); card.add(Box.createVerticalStrut(5)); card.add(userField); card.add(Box.createVerticalStrut(14));
        card.add(lbl("Құпия сөз", F_BOLD, C_TEXT)); card.add(Box.createVerticalStrut(5)); card.add(passField); card.add(Box.createVerticalStrut(6));
        card.add(errLbl); card.add(Box.createVerticalStrut(16)); card.add(loginBtn);
        right.add(card);

        JButton close = btn("✕", C_BG, C_TEXT); close.setPreferredSize(new Dimension(32, 32)); close.addActionListener(e->System.exit(0));
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,6)); topBar.setOpaque(false); topBar.add(close);

        makeDraggable(root, f);
        root.add(topBar, BorderLayout.NORTH); root.add(left, BorderLayout.WEST); root.add(right, BorderLayout.CENTER);
        f.setContentPane(root);

        Runnable doLogin = () -> {
            Database.User u = db.authenticate(userField.getText().trim(), new String(passField.getPassword()));
            if (u == null) { errLbl.setText("Қате логин немесе құпия сөз!"); return; }
            currentUser = u; f.dispose(); buildMainFrame();
        };
        loginBtn.addActionListener(e -> doLogin.run()); passField.addActionListener(e -> doLogin.run());
        f.setVisible(true);
    }
    //интерфейс құру
    void buildMainFrame() {
        mainFrame = new JFrame("Platonus Жүйесі"); mainFrame.setUndecorated(true); mainFrame.setSize(1280, 800); mainFrame.setLocationRelativeTo(null); mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(C_BG);

        JPanel bar = new JPanel(new BorderLayout()); bar.setBackground(C_SIDE); bar.setBorder(BorderFactory.createMatteBorder(0,0,1,0,C_BORDER)); bar.setPreferredSize(new Dimension(0, 55));
        JPanel barL = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 14)); barL.setOpaque(false);
        barL.add(lbl("Platonus", new Font("Segoe UI", Font.BOLD, 18), C_RED));

        JPanel barR = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10)); barR.setOpaque(false);
        JLabel uLbl = lbl("Қош келдіңіз, " + currentUser.fullName, F_BOLD, C_TEXT);
        JLabel rLbl = lbl(currentUser.roleLabel(), F_SMALL, C_MUTED);
        rLbl.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(2, 6, 2, 6)));

        JButton logout = btn("Шығу", C_BG, C_TEXT), minBtn = btn("—", C_BG, C_TEXT), closeB = btn("✕", C_RED, Color.WHITE);
        for (JButton b : new JButton[]{minBtn, closeB}) b.setPreferredSize(new Dimension(32, 32));
        minBtn.addActionListener(e->mainFrame.setState(JFrame.ICONIFIED)); closeB.addActionListener(e->System.exit(0));
        logout.addActionListener(e->{ mainFrame.dispose(); new UniversityApp().showLogin(); });

        barR.add(uLbl); barR.add(rLbl); barR.add(logout); barR.add(Box.createHorizontalStrut(5)); barR.add(minBtn); barR.add(closeB);
        bar.add(barL, BorderLayout.WEST); bar.add(barR, BorderLayout.EAST);
        makeDraggable(bar, mainFrame);

        JPanel sidebar = new JPanel(); sidebar.setBackground(C_SIDE_DARK); sidebar.setPreferredSize(new Dimension(210, 0)); sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS)); sidebar.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, C_BORDER));
        contentArea = new JPanel(new BorderLayout()); contentArea.setBackground(C_BG);

        sidebar.add(Box.createVerticalStrut(10));
        addSection(sidebar, "НЕГІЗГІ");
        if (currentUser.role != Database.User.Role.TEACHER) {
            addNav(sidebar, "▪", "Басты бет", ()->showDashboard());
        }

        addSection(sidebar, "ОҚУ ҮДЕРІСІ");
        if (currentUser.role == Database.User.Role.TEACHER) {
            addNav(sidebar, "▪", "Студенттер", ()->showStudents());
        }
        if (currentUser.role != Database.User.Role.TEACHER) {
            addNav(sidebar, "▪", "Пәндер", ()->showSubjects());
        }

        addNav(sidebar, "▪", "Журнал (Бағалар)", ()->showGrades());
        addSection(sidebar, "АНАЛИТИКА ЖӘНЕ ІЗДЕУ");
        addNav(sidebar, "▪", "Іздеу жүйесі", ()->showSearch());
        addNav(sidebar, "▪", "Сайт картасы (Есептер)", ()->showReports());
        sidebar.add(Box.createVerticalGlue());

        root.add(bar, BorderLayout.NORTH); sidebar.setVisible(true);
        root.add(sidebar, BorderLayout.WEST); root.add(contentArea, BorderLayout.CENTER);
        mainFrame.setContentPane(root); mainFrame.setVisible(true);

        if (currentUser.role == Database.User.Role.TEACHER) {
            showStudents();
        } else {
            showDashboard();
        }
    }

    void addSection(JPanel p, String t) {
        JLabel l = lbl(t, new Font("Segoe UI", Font.BOLD, 10), new Color(160, 170, 185)); l.setBorder(BorderFactory.createEmptyBorder(12, 18, 4, 18)); l.setAlignmentX(Component.LEFT_ALIGNMENT); p.add(l);
    }

    void addNav(JPanel sidebar, String icon, String name, Runnable action) {
        JButton b = new JButton(icon + "  " + name); b.setFont(F_BODY); b.setForeground(C_SIDE_TEXT); b.setBackground(C_SIDE_DARK); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT); b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); b.setMaximumSize(new Dimension(9999, 40)); b.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18)); b.setAlignmentX(Component.LEFT_ALIGNMENT);
        b.addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){ b.setBackground(C_SIDE_HOVER); b.setForeground(Color.WHITE); }
            public void mouseExited(MouseEvent e){ b.setBackground(C_SIDE_DARK); b.setForeground(C_SIDE_TEXT); }
        });
        b.addActionListener(e -> {
            for (Component c : sidebar.getComponents()) if (c instanceof JButton x) { x.setBackground(C_SIDE_DARK); x.setFont(F_BODY); x.setForeground(C_SIDE_TEXT); }
            b.setFont(F_BOLD); b.setForeground(Color.WHITE); action.run();
        });
        sidebar.add(b);
    }

    JPanel cardPanel(String title) {
        JPanel p = new JPanel(new BorderLayout()); p.setBackground(C_CARD); p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        JLabel t = lbl(title, F_HEAD, C_TEXT); t.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, C_BORDER), BorderFactory.createEmptyBorder(0, 0, 8, 0)));
        p.add(t, BorderLayout.NORTH); return p;
    }

    JPanel cardPanelRed(String title) {
        JPanel p = new JPanel(new BorderLayout()); p.setBackground(C_CARD); p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_RED, 1), BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        JLabel t = lbl(title, F_HEAD, Color.WHITE); t.setOpaque(true); t.setBackground(C_RED); t.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, C_BORDER), BorderFactory.createEmptyBorder(4, 10, 8, 10)));
        p.add(t, BorderLayout.NORTH); return p;
    }
    //карточка
    void showDashboard() {
        JPanel main = new JPanel(new BorderLayout()); main.setBackground(C_BG);

        JPanel hdr = new JPanel(new BorderLayout()); hdr.setBackground(C_REPORTS_BG); hdr.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        hdr.add(lbl("Басты бет", F_TITLE, Color.WHITE), BorderLayout.WEST);
        hdr.add(lbl("Жүйедегі ағымдағы ақпараттар көрсеткіші", F_BODY, new Color(240, 240, 240)), BorderLayout.EAST);

        JPanel content = new JPanel(); content.setOpaque(false); content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(20, 24, 24, 24));

        boolean isTeacher = (currentUser.role == Database.User.Role.TEACHER);
        JPanel cols = new JPanel(new GridLayout(1, isTeacher ? 2 : 1, 20, 0));
        cols.setOpaque(false); cols.setMaximumSize(new Dimension(9999, 450));

        JPanel hc = cardPanelRed("Маңызды хабар"); JPanel hbody = new JPanel(); hbody.setOpaque(false); hbody.setLayout(new BoxLayout(hbody, BoxLayout.Y_AXIS));
        JLabel msgTitle = lbl("Сізді ағымдық оқу кезеңінде(2) пәндер бойынша келмеулердің саны туралы хабарландырамыз:", F_BODY, C_TEXT);
        hbody.add(msgTitle); hbody.add(Box.createVerticalStrut(14));

        String[][] absData = {{"- 3D модельдеу(DTAF 201/2-2--L)", "1"}, {"- Инклюзивті білім беру(GER/201-99--P)", "4"}, {"- Дене шынықтыру(GES 204/-115-P)", "2"}};
        for (String[] rowData : absData) {
            JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false); row.add(lbl(rowData[0], F_BODY, C_MUTED), BorderLayout.WEST); row.add(lbl("-" + rowData[1], F_BOLD, C_RED), BorderLayout.EAST);
            hbody.add(row);
        }
        hbody.add(Box.createVerticalStrut(14)); JSeparator sep = new JSeparator(); sep.setForeground(C_BORDER); hbody.add(sep); hbody.add(Box.createVerticalStrut(8));
        hbody.add(lbl("Барлығы: 7", F_BOLD, C_TEXT)); hc.add(scroll(hbody), BorderLayout.CENTER); cols.add(hc);

        if (isTeacher) {
            JPanel tc = cardPanel("Үздік студенттер рейтингі (GPA)"), tbody = new JPanel(); tbody.setOpaque(false); tbody.setLayout(new BoxLayout(tbody, BoxLayout.Y_AXIS));
            db.allStudents().stream().sorted((a,b)->Double.compare(b.gpa(),a.gpa())).limit(6).forEach(s->{
                JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false); row.add(lbl(s.fullName(), F_BODY, C_TEXT), BorderLayout.WEST); row.add(lbl(String.format("GPA: %.2f", s.gpa()), F_BOLD, C_RED), BorderLayout.EAST);
                tbody.add(row); JSeparator sep2 = new JSeparator(); sep2.setForeground(C_BORDER); tbody.add(sep2);
            });
            tc.add(scroll(tbody), BorderLayout.CENTER); cols.add(tc);
        }
        content.add(cols); main.add(hdr, BorderLayout.NORTH); main.add(content, BorderLayout.CENTER);
        contentArea.removeAll(); contentArea.add(scroll(main), BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
    }

    // СТУДЕНТ БӨЛІМІ
    void showStudents() {
        if (currentUser.role == Database.User.Role.TEACHER) {
            JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(C_BG);
            JPanel hdr = new JPanel(new BorderLayout()); hdr.setBackground(C_REPORTS_BG); hdr.setBorder(BorderFactory.createEmptyBorder(15, 24, 15, 24));
            hdr.add(lbl("Студенттер базасы (Мұғалім режимі)", F_TITLE, Color.WHITE), BorderLayout.WEST);

            JPanel acts = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0)); acts.setOpaque(false);
            JTextField search = tf(); search.setPreferredSize(new Dimension(200, 36));
            JButton srchBtn = btnP("Іздеу"), addBtn = btnS("+ Жаңа студент"), delBtn = btnD();
            acts.add(search); acts.add(srchBtn); acts.add(addBtn); acts.add(delBtn); hdr.add(acts, BorderLayout.EAST);

            String[] cols = {"ID", "Тегі Аты", "Студент ID", "Топ", "Email", "Түрі", "Телефон нөмірі"};
            DefaultTableModel model = new DefaultTableModel(cols, 0){ public boolean isCellEditable(int r, int c){ return false; } };
            JTable table = new JTable(model); styleTable(table);
            table.getColumnModel().getColumn(0).setMaxWidth(45); table.getColumnModel().getColumn(5).setMaxWidth(90);

            JScrollPane sp = scroll(table); sp.setBorder(BorderFactory.createEmptyBorder(20, 24, 24, 24));
            JLabel status = lbl("", F_SMALL, C_MUTED); JPanel foot = new JPanel(new FlowLayout(FlowLayout.LEFT)); foot.setBackground(C_SIDE); foot.add(status);
            panel.add(hdr, BorderLayout.NORTH); panel.add(sp, BorderLayout.CENTER); panel.add(foot, BorderLayout.SOUTH);

            Runnable load = () -> {
                model.setRowCount(0); List<Database.Student> list = db.allStudents(); String q = search.getText().trim(); if (!q.isEmpty()) list = db.search(q);
                for (Database.Student s : list) model.addRow(new Object[]{ s.id, s.fullName(), s.studentId, s.group, s.email, s.fundingType, s.phoneNumber });
                status.setText(" Базада барлығы: " + list.size() + " студент тіркелген");
            };
            load.run(); srchBtn.addActionListener(e->load.run()); search.addActionListener(e->load.run());

            addBtn.addActionListener(e->{
                JDialog d = dialog("Жаңа студент тіркеу", 440, 480); JTextField fn = tf(), ln = tf(), sid = tf(), grp = tf(), email = tf();
                JPanel form = formPanel(); form.add(fRow("Аты", fn)); form.add(fRow("Тегі", ln)); form.add(fRow("Студент ID (Логин)", sid)); form.add(fRow("Академиялық топ", grp)); form.add(fRow("Email мекенжайы", email));
                JButton save = btnS("Сақтау"), cancel = btnN(); JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); btns.setOpaque(false); btns.add(save); btns.add(cancel); form.add(btns);
                save.addActionListener(x->{
                    db.addStudent(fn.getText().trim(), ln.getText().trim(), sid.getText().trim(), email.getText().trim(), grp.getText().trim());
                    load.run();
                    d.dispose();
                });
                cancel.addActionListener(x->d.dispose()); d.setContentPane(form); d.setVisible(true);
            });

            delBtn.addActionListener(e -> {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(panel, "Өшіру үшін алдымен кестеден студентті таңдаңыз!", "Ескерту", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                int idToDel = (int) model.getValueAt(selectedRow, 0);
                String nameToDel = (String) model.getValueAt(selectedRow, 1);

                int confirm = JOptionPane.showConfirmDialog(panel,
                        "Шынымен " + nameToDel + " есімді студентті базадан өшіресіз бе?",
                        "Жоюды растау", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    db.deleteStudent(idToDel);
                    load.run();
                    JOptionPane.showMessageDialog(panel, "Студент сәтті өшірілді!", "Нәтиже", JOptionPane.INFORMATION_MESSAGE);
                }
            });

            contentArea.removeAll(); contentArea.add(panel, BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
        }
    }
    // ПӘН БӨЛІМІ
    void showSubjects() {
        JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(C_BG);
        JPanel hdr = new JPanel(new BorderLayout()); hdr.setBackground(C_REPORTS_BG); hdr.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        hdr.add(lbl("Академиялық пәндер тізімі", F_TITLE, Color.WHITE), BorderLayout.WEST);

        boolean isStudent = (currentUser.role == Database.User.Role.STUDENT);
        String[] cols = isStudent ? new String[]{"ID", "Пән атауы", "Код", "Кредит саны", "Бекітілген оқытушы"} : new String[]{"ID", "Пән атауы", "Код", "Кредит саны", "Бекітілген оқытушы", "Тіркелген Студент", "Орташа балл"};
        DefaultTableModel model = new DefaultTableModel(cols, 0){ public boolean isCellEditable(int r, int c){ return false; } };
        JTable table = new JTable(model); styleTable(table);

        JScrollPane sp = scroll(table); sp.setBorder(BorderFactory.createEmptyBorder(20, 24, 24, 24)); panel.add(hdr, BorderLayout.NORTH); panel.add(sp, BorderLayout.CENTER);
        db.allSubjects().forEach(s->{
            if (isStudent) model.addRow(new Object[]{s.id, s.name, s.code, s.credits, s.teacher});
            else model.addRow(new Object[]{s.id, s.name, s.code, s.credits, s.teacher, db.gradesBySubject(s.id).size(), String.format("%.1f балл", db.avgBySubject(s.id))});
        });
        contentArea.removeAll(); contentArea.add(panel, BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
    }
    // БАҒАЛАР БӨЛІМІ
    void showGrades() {
        JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(C_BG);
        JPanel hdr = new JPanel(new BorderLayout()); hdr.setBackground(C_REPORTS_BG); hdr.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        hdr.add(lbl(currentUser.role == Database.User.Role.STUDENT ? "Менің оқу үлгерімім" : "Оқу үлгерімі журналы", F_TITLE, Color.WHITE), BorderLayout.WEST);

        if (currentUser.role == Database.User.Role.STUDENT) {
            List<Database.Grade> list = db.allGrades().stream().filter(g -> g.student.studentId.equalsIgnoreCase(currentUser.username) || g.student.fullName().equalsIgnoreCase(currentUser.fullName)).collect(Collectors.toList());
            JPanel gridContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 15)); gridContainer.setBackground(C_BG);
            for (Database.Grade g : list) { gridContainer.add(createPlatonusCard(g)); }
            panel.add(hdr, BorderLayout.NORTH); panel.add(scroll(gridContainer), BorderLayout.CENTER);
        } else {
            JPanel fbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8)); fbar.setBackground(C_CARD); fbar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, C_BORDER));
            fbar.add(lbl("Сүзгі деңгейі:", F_BOLD, C_TEXT));
            JComboBox<String> stF = new JComboBox<>(); stF.addItem("Барлық студенттер"); db.allStudents().forEach(s->stF.addItem(s.fullName())); fbar.add(stF);
            JComboBox<String> subF = new JComboBox<>(); subF.addItem("Барлық пәндер"); db.allSubjects().forEach(s->subF.addItem(s.name)); fbar.add(subF);
            JButton apply = btnP("Іздеуді қолдану"); fbar.add(apply); JPanel north = new JPanel(new BorderLayout()); north.add(hdr, BorderLayout.NORTH); north.add(fbar, BorderLayout.SOUTH);

            String[] cols = {"ID", "Студенттің Тегі Аты", "Пән атауы", "Жалпы балл", "Әріптік баға", "GPA", "Ағымдағы семестр"};
            DefaultTableModel model = new DefaultTableModel(cols, 0){ public boolean isCellEditable(int r, int c){ return false; } };
            JTable table = new JTable(model); styleTable(table); JScrollPane sp = scroll(table); sp.setBorder(BorderFactory.createEmptyBorder(20, 24, 24, 24));
            panel.add(north, BorderLayout.NORTH); panel.add(sp, BorderLayout.CENTER);

            table.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer(){
                @Override
                public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c){
                    super.getTableCellRendererComponent(t, v, s, f, r, c); setBackground(s ? new Color(194, 24, 71, 30) : C_CARD);
                    setForeground(C_RED); setFont(F_BOLD); setHorizontalAlignment(CENTER); return this;
                }
            });

            Runnable loadTable = () -> {
                model.setRowCount(0); List<Database.Grade> gList = db.allGrades();
                int si = stF.getSelectedIndex(); if (si > 0) { int id = db.allStudents().get(si - 1).id; gList = gList.stream().filter(g->g.student.id == id).collect(Collectors.toList()); }
                int subi = subF.getSelectedIndex(); if (subi > 0) { int id = db.allSubjects().get(subi - 1).id; gList = gList.stream().filter(g->g.subject.id == id).collect(Collectors.toList()); }
                gList.forEach(g->model.addRow(new Object[]{g.id, g.student.fullName(), g.subject.name, g.score, g.letter(), String.format("%.2f", g.gpaValue()), g.semester}));
            }; loadTable.run(); apply.addActionListener(e->loadTable.run());
        }
        contentArea.removeAll(); contentArea.add(panel, BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
    }

    private JPanel createPlatonusCard(Database.Grade g) {
        JPanel card = new JPanel(); card.setPreferredSize(new Dimension(245, 450)); card.setBackground(C_CARD);
        card.setBorder(BorderFactory.createLineBorder(C_BORDER, 1)); card.setLayout(new BorderLayout());
        boolean isZero = (g.score <= 0); Color headerColor = isZero ? Color.GRAY : (g.score >= 90 ? C_GREEN : C_BLUE);
        JPanel topPanel = new JPanel(new BorderLayout()); topPanel.setBackground(headerColor); topPanel.setPreferredSize(new Dimension(0, 55));
        JLabel title = lbl("<html><center>" + g.subject.name + "</center></html>", F_BOLD, Color.WHITE); title.setHorizontalAlignment(SwingConstants.CENTER); topPanel.add(title, BorderLayout.CENTER);

        JPanel centerPanel = new JPanel() {
            protected void paintComponent(Graphics graph) {
                super.paintComponent(graph); Graphics2D g2 = (Graphics2D) graph; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(235, 238, 243)); g2.setStroke(new BasicStroke(8)); g2.drawOval(50, 10, 90, 90);
                if (!isZero) { g2.setColor(headerColor); g2.drawArc(50, 10, 90, 90, 90, (int)(-(g.score / 100.0) * 360)); }
            }
        }; centerPanel.setOpaque(false); centerPanel.setLayout(null); centerPanel.setPreferredSize(new Dimension(0, 110));
        JLabel scoreLbl = lbl(isZero ? "0.0" : g.score + "%", F_TITLE, C_TEXT); scoreLbl.setBounds(50, 40, 90, 30); scoreLbl.setHorizontalAlignment(SwingConstants.CENTER); centerPanel.add(scoreLbl);

        JPanel botPanel = new JPanel(new GridLayout(4, 3, 2, 2)); botPanel.setOpaque(false); botPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        if (isZero) {
            botPanel.add(lbl("", F_SMALL, C_MUTED)); botPanel.add(lbl("Рұқсат", F_SMALL, C_MUTED)); botPanel.add(lbl("", F_SMALL, C_MUTED));
            botPanel.add(lbl("", F_SMALL, C_MUTED)); botPanel.add(lbl("   Т", F_BOLD, headerColor)); for (int i = 0; i < 7; i++) botPanel.add(lbl("", F_SMALL, C_MUTED));
        } else {
            botPanel.add(lbl(String.format("%.1f", g.score*0.98), F_BODY, C_TEXT)); botPanel.add(lbl(String.format("%.1f", g.score*0.97), F_BODY, C_TEXT)); botPanel.add(lbl(String.format("%.1f", g.score*0.975), F_BODY, C_TEXT));
            botPanel.add(lbl("Орт.ағым.1", F_SMALL, C_MUTED)); botPanel.add(lbl("Орт.ағым.2", F_SMALL, C_MUTED)); botPanel.add(lbl("АБ 1", F_SMALL, C_MUTED));
            botPanel.add(lbl(String.format("%.1f", g.score), F_BOLD, headerColor)); botPanel.add(lbl(String.format("%.1f", g.score*1.03), F_BODY, C_TEXT)); botPanel.add(lbl(String.format("%.1f", g.score*0.92), F_BODY, C_TEXT));
            botPanel.add(lbl("Рейтинг", F_SMALL, C_MUTED)); botPanel.add(lbl("АБ 2", F_SMALL, C_MUTED)); botPanel.add(lbl("Емт.", F_SMALL, C_MUTED));
        }
        card.add(topPanel, BorderLayout.NORTH); JPanel cb = new JPanel(new BorderLayout()); cb.setOpaque(false); cb.add(centerPanel, BorderLayout.NORTH); cb.add(botPanel, BorderLayout.CENTER); card.add(cb, BorderLayout.CENTER); return card;
    }
    // ІЗДЕУ БӨЛІМІ
    void showSearch() {
        JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(C_BG);
        JPanel sbar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12)); sbar.setBackground(C_CARD);
        JTextField sf = tf(); sf.setPreferredSize(new Dimension(450, 38)); JButton sb = btnP("Іздеу"); sbar.add(sf); sbar.add(sb); panel.add(sbar, BorderLayout.NORTH);
        JPanel results = new JPanel(new BorderLayout()); results.setBackground(C_BG); results.setBorder(BorderFactory.createEmptyBorder(16, 24, 24, 24)); panel.add(results, BorderLayout.CENTER);
        sb.addActionListener(e -> {
            results.removeAll(); String q = sf.getText().trim().toLowerCase(); if (q.isEmpty()) return;
            List<Database.Student> list = db.search(q); String[] cols = {"Тегі Аты", "ID", "Топ", "Email"};
            DefaultTableModel m = new DefaultTableModel(cols, 0); list.forEach(s->m.addRow(new Object[]{s.fullName(), s.studentId, s.group, s.email}));
            JTable t = new JTable(m); styleTable(t); results.add(scroll(t), BorderLayout.CENTER); results.revalidate(); results.repaint();
        });
        contentArea.removeAll(); contentArea.add(panel, BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
    }
    // ЕСЕПТЕР ЖӘНЕ GPA
    void showReports() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(C_REPORTS_BG);

        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(C_REPORTS_BG);
        hdr.setBorder(BorderFactory.createEmptyBorder(20, 24, 15, 24));
        hdr.add(lbl("Сайт картасы және статистикалық есептер", F_TITLE, Color.WHITE), BorderLayout.WEST); panel.add(hdr, BorderLayout.NORTH);

        boolean isTeacher = (currentUser.role == Database.User.Role.TEACHER);

        if (isTeacher) {
            JPanel dashboardPanel = new JPanel(); dashboardPanel.setBackground(Color.WHITE);
            dashboardPanel.setLayout(new BoxLayout(dashboardPanel, BoxLayout.Y_AXIS));
            dashboardPanel.setBorder(BorderFactory.createEmptyBorder(20, 16, 16, 16));

            JPanel cardsRow = new JPanel(new GridLayout(1, 3, 20, 0)); cardsRow.setOpaque(false);
            cardsRow.setMaximumSize(new Dimension(9999, 90));

            double totalAvg = db.allGrades().stream().mapToDouble(g -> g.score).average().orElse(0.0);
            Database.Student bestStudent = db.allStudents().stream().max(Comparator.comparingDouble(Database.Student::gpa)).orElse(null);
            Database.Subject bestSub = db.allSubjects().stream().max(Comparator.comparingDouble(s -> db.avgBySubject(s.id))).orElse(null);

            cardsRow.add(createStatCard("Жалпы орташа үлгерім", String.format("%.1f балл", totalAvg), C_BLUE));
            cardsRow.add(createStatCard("Поток белсендісі (Top Student)", bestStudent != null ? bestStudent.fullName() : "—", C_RED));
            cardsRow.add(createStatCard("Көшбасшы пән (Top Subject)", bestSub != null ? bestSub.name : "—", C_GREEN));
            dashboardPanel.add(cardsRow); dashboardPanel.add(Box.createVerticalStrut(24));

            JPanel contentRow = new JPanel(new GridLayout(1, 2, 24, 0)); contentRow.setOpaque(false);

            JPanel subPanel = new JPanel(); subPanel.setBackground(C_BG); subPanel.setLayout(new BoxLayout(subPanel, BoxLayout.Y_AXIS));
            subPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(15, 20, 15, 20)));
            JLabel subTitle = lbl("Пәндер аналитикасы және орташа көрсеткіштер", F_HEAD, C_TEXT);
            subTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0)); subPanel.add(subTitle);

            db.allSubjects().forEach(s -> {
                double avg = db.avgBySubject(s.id);
                JPanel item = new JPanel(new BorderLayout()); item.setOpaque(false); item.setMaximumSize(new Dimension(9999, 45));
                item.add(lbl(s.name, F_BODY, C_TEXT), BorderLayout.WEST);
                item.add(lbl(String.format("%.1f%%", avg), F_BOLD, avg >= 80 ? C_GREEN : C_BLUE), BorderLayout.EAST);
                JProgressBar bar = new JProgressBar(0, 100); bar.setValue((int) avg);
                bar.setForeground(avg >= 80 ? C_GREEN : C_BLUE); bar.setBackground(new Color(235, 240, 245));
                bar.setBorderPainted(false); bar.setPreferredSize(new Dimension(0, 6));
                JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false);
                wrap.setBorder(BorderFactory.createEmptyBorder(4, 0, 12, 0)); wrap.add(bar, BorderLayout.CENTER);
                subPanel.add(item); subPanel.add(wrap);
            });

            JPanel rankPanel = new JPanel(); rankPanel.setBackground(C_BG); rankPanel.setLayout(new BoxLayout(rankPanel, BoxLayout.Y_AXIS));
            rankPanel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(15, 20, 15, 20)));
            JLabel rankTitle = lbl("Студенттер GPA Рейтингі (Топ 10)", F_HEAD, C_TEXT);
            rankTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0)); rankPanel.add(rankTitle);

            int[] index = {1};
            db.allStudents().stream().sorted((a, b) -> Double.compare(b.gpa(), a.gpa())).limit(10).forEach(s -> {
                JPanel row = new JPanel(new BorderLayout()); row.setOpaque(false); row.setMaximumSize(new Dimension(9999, 36));
                row.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(245, 245, 245)));
                JLabel nameLabel = lbl(index[0] + ".  " + s.fullName() + " [" + s.group + "]", F_BODY, C_TEXT);
                JLabel scoreLabel = lbl(String.format("GPA: %.2f", s.gpa()), F_BOLD, C_RED);
                row.add(nameLabel, BorderLayout.WEST); row.add(scoreLabel, BorderLayout.EAST);
                rankPanel.add(row); rankPanel.add(Box.createVerticalStrut(4));
                index[0]++;
            });

            contentRow.add(scroll(subPanel)); contentRow.add(scroll(rankPanel));
            dashboardPanel.add(contentRow); panel.add(dashboardPanel, BorderLayout.CENTER);
        } else {
            JPanel mainPanel = new JPanel(new BorderLayout()); mainPanel.setBackground(C_BG);
            mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            JPanel calcBox = new JPanel(); calcBox.setBackground(C_CARD); calcBox.setLayout(new BoxLayout(calcBox, BoxLayout.Y_AXIS));
            calcBox.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(C_BORDER, 1), BorderFactory.createEmptyBorder(30, 40, 30, 40)));

            calcBox.add(lbl("Сессиядан қанша балл алу керек?", F_TITLE, C_RED)); calcBox.add(Box.createVerticalStrut(4));
            calcBox.add(lbl("Пәнді таңдап, қалаған қорытынды балл мәнін жазыңыз:", F_BODY, C_MUTED)); calcBox.add(Box.createVerticalStrut(25));

            JComboBox<Database.Subject> subCombo = new JComboBox<>(); subCombo.setBackground(C_INPUT); subCombo.setFont(F_BOLD); db.allSubjects().forEach(subCombo::addItem);
            subCombo.setMaximumSize(new Dimension(500, 38)); subCombo.setAlignmentX(Component.LEFT_ALIGNMENT);
            calcBox.add(lbl("Академиялық пәнді таңдаңыз:", F_BOLD, C_TEXT)); calcBox.add(Box.createVerticalStrut(6)); calcBox.add(subCombo); calcBox.add(Box.createVerticalStrut(20));

            JTextField targetScoreField = tf(); targetScoreField.setMaximumSize(new Dimension(500, 38)); targetScoreField.setAlignmentX(Component.LEFT_ALIGNMENT); targetScoreField.setText("95");
            calcBox.add(lbl("Қалаған қорытынды жалпы балл мәні (0-100):", F_BOLD, C_TEXT)); calcBox.add(Box.createVerticalStrut(6)); calcBox.add(targetScoreField); calcBox.add(Box.createVerticalStrut(20));

            JButton calculateBtn = btnP("Жинақ баллды есептеу"); calculateBtn.setMaximumSize(new Dimension(500, 40)); calculateBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
            calcBox.add(calculateBtn); calcBox.add(Box.createVerticalStrut(25));

            JPanel resCard = new JPanel(new BorderLayout()){ protected void paintComponent(Graphics g){ super.paintComponent(g); g.setColor(C_RED); g.fillRect(0, 0, 5, getHeight()); } };
            resCard.setBackground(new Color(248, 249, 250)); resCard.setBorder(BorderFactory.createLineBorder(C_BORDER, 1)); resCard.setMaximumSize(new Dimension(500, 90)); resCard.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel resText = lbl(" Енгізілген мәліметтер бойынша есептеу нәтижесі осында шығады...", F_BODY, C_TEXT); resText.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10)); resCard.add(resText, BorderLayout.CENTER); calcBox.add(resCard);

            calculateBtn.addActionListener(e -> {
                try {
                    double targetValue = Double.parseDouble(targetScoreField.getText().trim());
                    if (targetValue < 0 || targetValue > 100) { resText.setText("<html><span style='color:red;'>Қате! Балл мәні 0 мен 100 аралығында болуы тиіс.</span></html>"); return; }
                    Database.Subject selSub = (Database.Subject) subCombo.getSelectedItem(); if (selSub == null) return;
                    List<Database.Grade> sGrades = db.allGrades().stream().filter(gr -> gr.student.studentId.equalsIgnoreCase(currentUser.username) || gr.student.fullName().equalsIgnoreCase(currentUser.fullName)).collect(Collectors.toList());
                    double currentRating = sGrades.stream().filter(gr -> gr.subject.id == selSub.id).mapToDouble(gr -> gr.score).findFirst().orElse(0.0);
                    if (currentRating <= 0) currentRating = 75.0;
                    double requiredExam = (targetValue - (currentRating * 0.6)) / 0.4; if (requiredExam < 50) requiredExam = 50.0;
                    if (requiredExam > 100) { resText.setText("<html>Ағымдық рейтинг балыңыз: <b>" + currentRating + "</b>.<br><span style='color:red;'>Өкінішке орай, сессияда 100 балл алсаңыз да қорытынды " + targetValue + " балл жинау мүмкін емес!</span></html>"); }
                    else { resText.setText("<html>Ағымдық рейтинг балыңыз: <b>" + currentRating + "</b>.<br>Қорытынды жалпы <b>" + targetValue + " балл</b> жинау үшін сессиядан (емтиханнан) кем дегенде: <b><span style='color:green; font-size:14px;'>" + String.format("%.1f", requiredExam) + " балл</span></b> алуыңыз керек.</html>"); }
                } catch (NumberFormatException ex) { resText.setText("<html><span style='color:red;'>Қате! Сандық мәнді дұрыс енгізіңіз (Мысалы: 90 немесе 85.5).</span></html>"); }
            });
            mainPanel.add(scroll(calcBox), BorderLayout.CENTER); panel.add(mainPanel, BorderLayout.CENTER);
        }
        contentArea.removeAll(); contentArea.add(panel, BorderLayout.CENTER); contentArea.revalidate(); contentArea.repaint();
    }

    private JPanel createStatCard(String title, String val, Color barColor) {
        JPanel c = new JPanel(new BorderLayout()) {
            protected void paintComponent(Graphics g) { super.paintComponent(g); g.setColor(barColor); g.fillRect(0, 0, 4, getHeight()); }
        };
        c.setBackground(C_CARD); c.setBorder(BorderFactory.createLineBorder(C_BORDER, 1));
        JPanel inner = new JPanel(new GridLayout(2, 1, 0, 2)); inner.setOpaque(false);
        inner.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));
        inner.add(lbl(title, F_SMALL, C_MUTED)); inner.add(lbl(val, F_HEAD, C_TEXT));
        c.add(inner, BorderLayout.CENTER); return c;
    }

    JDialog dialog(String title, int w, int h) { JDialog d = new JDialog(mainFrame, title, true); d.setSize(w, h); d.setLocationRelativeTo(mainFrame); return d; }
    JPanel formPanel(){ JPanel p = new JPanel(); p.setBackground(C_CARD); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); p.setBorder(BorderFactory.createEmptyBorder(20, 22, 20, 22)); return p; }

    private JPanel createFormRow(String label, JComponent comp) {
        JPanel p = new JPanel(); p.setOpaque(false); p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS)); p.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel l = lbl(label, F_BOLD, C_TEXT); l.setAlignmentX(Component.LEFT_ALIGNMENT); comp.setAlignmentX(Component.LEFT_ALIGNMENT);
        p.add(l); p.add(Box.createVerticalStrut(4)); p.add(comp); p.add(Box.createVerticalStrut(10)); return p;
    }
    JPanel fRow(String label, JTextField field){ return createFormRow(label, field); }
    JPanel fRow2(String label, JComboBox<?> cb){ cb.setMaximumSize(new Dimension(9999, 36)); return createFormRow(label, cb); }
}