import java.util.*;
import java.util.stream.*;

public class Database {
    private static Database instance;
    public static Database get() { if(instance==null) instance=new Database(); return instance; }

    public static class User {
        public enum Role { TEACHER, STUDENT }
        public String username, fullName; public Role role;
        User(String u, String f, Role r){ username=u; fullName=f; role=r; }
        public String roleLabel() { return role==Role.TEACHER?"Оқытушы (Админ)":"Студент"; }
    }

    public static class Subject {
        public int id, credits; public String name, code, teacher;
        Subject(int i, String n, String c, int cr, String t){ id=i; name=n; code=c; credits=cr; teacher=t; }
        public String toString() { return name + " (" + code + ")"; }
    }

    public static class Student {
        public int id; public String firstName, lastName, studentId, email, group, fundingType, phoneNumber;
        Student(int i, String f, String l, String s, String e, String g, String fund, String phone){
            id=i; firstName=f; lastName=l; studentId=s; email=e; group=g; fundingType=fund; phoneNumber=phone;
        }
        public String fullName() { return lastName + " " + firstName; }
        public double avgScore() {
            List<Grade> gs = Database.get().gradesByStudent(id);
            return gs.isEmpty() ? 0 : gs.stream().filter(g->g.score>0).mapToDouble(g->g.score).average().orElse(0);
        }
        public double gpa() {
            List<Grade> gs = Database.get().gradesByStudent(id);
            return gs.isEmpty() ? 0 : gs.stream().filter(g->g.score>0).mapToDouble(Grade::gpaValue).average().orElse(0);
        }
        public String toString() { return fullName() + " [" + group + "]"; }
    }

    public static class Grade {
        public int id; public Student student; public Subject subject; public double score; public String semester;
        Grade(int i, Student st, Subject sb, double sc, String sem){ id=i; student=st; subject=sb; score=sc; semester=sem; }
        public String letter() {
            if(score>=95) return "A";   if(score>=90) return "A-";  if(score>=85) return "B+";
            if(score>=80) return "B";   if(score>=75) return "B-";  if(score>=70) return "C+";
            if(score>=65) return "C";   if(score>=60) return "C-";  if(score>=55) return "D+";
            if(score>=50) return "D";   return "F";
        }
        public double gpaValue() {
            if(score>=95) return 4.0;   if(score>=90) return 3.67;  if(score>=85) return 3.33;
            if(score>=80) return 3.0;   if(score>=75) return 2.67;  if(score>=70) return 2.33;
            if(score>=65) return 2.0;   if(score>=60) return 1.67;  if(score>=55) return 1.33;
            if(score>=50) return 1.0;   return 0.0;
        }
    }

    private List<User> users = new ArrayList<>();
    private List<Subject> subjects = new ArrayList<>();
    private List<Student> students = new ArrayList<>();
    private List<Grade> grades = new ArrayList<>();
    private int idGen = 100;

    private Database() {
        users.add(new User("teacher", "Бекова Г.А.", User.Role.TEACHER));
        users.add(new User("student", "Алтынбек Нұрлыай", User.Role.STUDENT));

        subjects.add(new Subject(6, "Деректер базасы", "DB201", 5, "Бекова Г.А."));
        subjects.add(new Subject(7, "Дене шынықтыру(GES 204/-115-P)", "GES204", 2, "Буркитбаева М.Ж."));
        subjects.add(new Subject(8, "Программалау технологиялары 2(PLT 203)", "PLT203", 5, "Калымова К.А."));
        subjects.add(new Subject(9, "Объектіге бағытталған программалау", "PLT204", 5, "Ауелбеков О.А."));
        subjects.add(new Subject(10, "Оқу практикасы(ТP 206-10 SP)", "TP206", 3, "Бахытжанулы Д."));
        subjects.add(new Subject(11, "3D модельдеу(DTAF 201/2-2--L)", "DTAF201", 4, "Калымова К.А."));
        subjects.add(new Subject(12, "Инклюзивті білім беру(GER/201-4)", "GER201", 2, "Мажинов Б.М."));

        // Рандом телефон нөмірлерін жасау генераторы
        Random rand = new Random();
        String[] prefixes = {"+7 707 ", "+7 747 ", "+7 777 ", "+7 705 ", "+7 702 "};

        // 25 Студенттің толық тізімі (Түрі: Грант, Телефон: Рандом)
        students.add(new Student(1, "Нұрлыай", "Алтынбек", "student", "altynbek.n@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(2, "Жанерке", "Амирханова", "student2", "amirkhanova.z@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(3, "Аяжан", "Ахметова", "student3", "akhmetova.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(4, "Қырмызы-Сұлу", "Әбдіқұлова", "student4", "abdikulova.k@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(5, "Бүлдіршін", "Әли", "student5", "ali.b@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(6, "Жансая", "Байтөре", "student6", "baitore.zh@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(7, "Сумайа", "Бақыт", "student7", "bakyt.s@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(8, "Амина", "Бахтияр", "student8", "bakhtiyar.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(9, "Сезім", "Доғдырбай", "student9", "dogdyrbai.s@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(10, "Дамира", "Дүйсенбай", "student10", "duisenbai.d@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(11, "Ақерке", "Еділ", "student11", "edil.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(12, "Гүлзина", "Ермекова", "student12", "ermekova.g@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(13, "Әсемай", "Жарылқасын", "student13", "zharylkasyn.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(14, "Нұрсулу", "Қайым", "student14", "kaiym.n@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(15, "Асылай", "Қасым", "student15", "kasym.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(16, "Жансая", "Мәден", "student16", "maden.zh@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(17, "Зарина", "Минаварова", "student17", "minavarova.z@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(18, "Жулдыз", "Нурмаханова", "student18", "nurmakhanova.zh@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(19, "Дина", "Нұрлан", "student19", "nurlan.d@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(20, "Музаяна", "Сайлау", "student20", "sailau.m@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(21, "Айсулу", "Сапаргали", "student21", "sapargali.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(22, "Айгерім", "Усен", "student22", "usen.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(23, "Алина", "Хайрулла", "student23", "khayrulla.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(24, "Дамила", "Хамит", "student24", "khamit.d@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));
        students.add(new Student(25, "Ақжан", "Юсупбай", "student25", "yusupbai.a@edu.kz", "CS-2401", "Грант", genPhone(rand, prefixes)));

        // Барлық студенттерге баға үлестіру
        int gradeId = 1;
        for (Student student : students) {
            for (Subject subject : subjects) {
                double randomScore = 60.0 + (rand.nextDouble() * 38.0);
                randomScore = Math.round(randomScore * 10.0) / 10.0;
                grades.add(new Grade(gradeId++, student, subject, randomScore, "2026-Көктем"));
            }
        }
    }

    // Нөмірді рандомды түрде форматтау көмекші функциясы
    private String genPhone(Random r, String[] pref) {
        return pref[r.nextInt(pref.length)] + String.format("%03d-%02d-%02d", r.nextInt(1000), r.nextInt(100), r.nextInt(100));
    }

    public User authenticate(String u, String p) {
        return users.stream().filter(x->x.username.equalsIgnoreCase(u) && p.endsWith("123")).findFirst().orElse(null);
    }

    public List<Student> allStudents() { return new ArrayList<>(students); }
    public List<Subject> allSubjects() { return new ArrayList<>(subjects); }
    public List<Grade> allGrades() { return new ArrayList<>(grades); }

    public List<Student> search(String q) {
        String f = q.toLowerCase();
        return students.stream().filter(s->s.fullName().toLowerCase().contains(f) || s.studentId.toLowerCase().contains(f) || s.group.toLowerCase().contains(f)).collect(Collectors.toList());
    }

    public List<Grade> gradesByStudent(int sid) { return grades.stream().filter(g->g.student.id==sid).collect(Collectors.toList()); }
    public List<Grade> gradesBySubject(int subId) { return grades.stream().filter(g->g.subject.id==subId).collect(Collectors.toList()); }

    public double avgBySubject(int subId) {
        List<Grade> filtered = gradesBySubject(subId).stream().filter(g->g.score>0).collect(Collectors.toList());
        return filtered.isEmpty() ? 0 : filtered.stream().mapToDouble(g->g.score).average().orElse(0);
    }

    public Student studentById(int id) { return students.stream().filter(x->x.id==id).findFirst().orElse(null); }

    public void addStudent(String f, String l, String sid, String e, String g) {
        Random rand = new Random();
        String[] prefixes = {"+7 707 ", "+7 747 ", "+7 777 ", "+7 705 ", "+7 702 "};

        // Жаңа студент қосқанда автоматты түрде "Грант" және рандом нөмір тіркеледі
        Student newStudent = new Student(idGen++, f, l, sid, e, g, "Грант", genPhone(rand, prefixes));
        students.add(newStudent);
        users.add(new User(sid, l + " " + f, User.Role.STUDENT));

        for (Subject subject : subjects) {
            double randomScore = 60.0 + (rand.nextDouble() * 38.0);
            randomScore = Math.round(randomScore * 10.0) / 10.0;
            grades.add(new Grade(idGen++, newStudent, subject, randomScore, "2026-Көктем"));
        }
    }

    public void deleteStudent(int id) { students.removeIf(x->x.id==id); grades.removeIf(x->x.student.id==id); }

    public void addGrade(Student st, Subject sb, double sc, String sem) {
        grades.removeIf(g -> g.student.id == st.id && g.subject.id == sb.id);
        grades.add(new Grade(idGen++, st, sb, sc, sem));
    }
}